

var popupoverlay=document.querySelector(".pop-overlay")
var popupbox=document.querySelector(".popupbook")

function show(){
    popupoverlay.style.display="block"
    popupbox.style.display="block"}
function cancel(){
  popupoverlay.style.display="none"
  popupbox.style.display="none"}


var popupoverlay1=document.querySelector("#pop-overlay1")
var popupbox1=document.querySelector("#popupbook1")

function show1(){
    popupoverlay1.style.display="block"
    popupbox1.style.display="block"}
function cancel1(){
  popupoverlay1.style.display="none"
  popupbox1.style.display="none"}
